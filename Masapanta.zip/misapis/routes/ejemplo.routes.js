import { Router } from 'express';
const ejemplo = Router();

// Obtener todos
ejemplo.get('/', (req, res) => {
  res.json({
    msg: 'get all API'
  });
});

// Obtener uno por ID
ejemplo.get('/:id', (req, res) => {
  const id = req.params.id; // era req.parama.id → incorrecto
  res.json({
    msg: 'get one API',
    id
  });
});

// Actualizar
ejemplo.put('/', (req, res) => {
  const body = req.body;
  res.json({
    msg: 'put API',
    body
  });
});

// Crear
ejemplo.post('/', (req, res) => {
  const body = req.body;
  res.json({
    msg: 'post API',
    body
  });
});

// Eliminar
ejemplo.delete('/:id', (req, res) => { // le faltaba ":" antes de id
  const id = req.params.id;
  res.json({
    msg: 'delete API',
    id
  });
});

export default ejemplo;