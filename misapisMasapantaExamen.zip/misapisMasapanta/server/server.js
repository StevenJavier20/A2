import express from 'express';
import 'dotenv/config';
console.log(process.env.MONGO_URI); // ← agrega esto temporalmente
import cors from 'cors';
import indexRoutes from '../routes/index.routes.js';
import * as db from '../db/cnn_mongodb.js';

export default class Server {
  constructor() {
    this.app = express();
    this.port = process.env.PORT || 3000;
    this.generalRoute = '/api/';
    this.conectarDBMongo(); // se llama al iniciar el servidor

    // Middlewares
    this.middlewares();

    // Rutas de mi aplicación
    this.routes();
  }

  // ✅ Aquí está la versión correcta
  async conectarDBMongo() {
    await db.conectarAMongoDB();
  }

  middlewares() {
    // CORS
    this.app.use(cors());

    // Lectura y parseo del body
    this.app.use(express.json());

    // Directorio público
    this.app.use(express.static('public'));
  }

  routes() {
    // localhost:3000/api/ejemplo
    this.app.use(this.generalRoute, indexRoutes);
    this.app.use(/.*/, (req, res) => {
      res.status(404).json({
        msg: 'Ruta no encontrada'
      });
    });
  }

  listen() {
    this.app.listen(this.port, () => {
      console.log(`✅ Servidor corriendo en puerto ${this.port}`);
    });
  }
}