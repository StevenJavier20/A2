import { Router } from 'express';
import { getAllUsuarios, postUsuario, putUsuario, deleteUsuario } from '../controllers/user.controller.js';

const userRouter = Router();

userRouter.get('/', getAllUsuarios);
userRouter.post('/', postUsuario);
userRouter.put('/:id', putUsuario);
userRouter.delete('/:id', deleteUsuario);

export default userRouter;