import { Router } from 'express';
import ejemplo from './ejemplo.routes.js';
import userRouter from './user.routes.js';
import empresaRouter from './empresa.routes.js'; // 👈 Importa AeroLogix

const indexRoutes = Router();

indexRoutes.use('/empresa', empresaRouter); // 👈 Agrega primero para mostrar la marca
indexRoutes.use('/usuarios', userRouter);
indexRoutes.use('/ejemplo', ejemplo);

export default indexRoutes;