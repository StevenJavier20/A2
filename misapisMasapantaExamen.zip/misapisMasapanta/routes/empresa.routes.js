import { Router } from 'express';
import { getInfoEmpresa, getEstadoEmpresa } from '../controllers/empresa.controller.js';

const router = Router();

// Información general
router.get('/', getInfoEmpresa);

// Estado actual de usuarios y sistema
router.get('/estado', getEstadoEmpresa);

export default router;