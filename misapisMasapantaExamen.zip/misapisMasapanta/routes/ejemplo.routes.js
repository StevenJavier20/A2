import { Router } from 'express';
import{
  getAllEjemplos, getEjemploById, postEjemplo, putEjemplo, deleteEjemplo
}from '../controllers/ejemplo.controller.js';
const ejemplo = Router();

// Obtener todos
ejemplo.get('/', getAllEjemplos);

// Obtener uno por ID
ejemplo.get('/:id', getEjemploById);

// Actualizar
ejemplo.put('/',putEjemplo);

// Crear
ejemplo.post('/', postEjemplo);

// Eliminar
ejemplo.delete('/:id', deleteEjemplo);

export default ejemplo;