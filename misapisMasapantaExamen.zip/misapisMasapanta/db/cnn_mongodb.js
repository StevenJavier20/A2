import mongoose from 'mongoose';

let isConected = false;

const conectarAMongoDB = async () => {
  try {
    if (isConected) {
      console.log('🟢 Ya está conectado a MongoDB');
      return;
    }

    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/tuBaseDeDatos', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    isConected = true;
    console.log('✅ Conectado a MongoDB');
  } catch (error) {
    console.error('❌ Error al conectar a MongoDB:', error.message);
  }
};

const db = mongoose.connection;

db.on('error', () => {
  isConected = false;
  console.log('🔴 Error en la conexión con MongoDB');
});

db.once('open', () => {
  isConected = true;
  console.log('🟢 Conexión establecida con MongoDB');
});

db.on('disconnected', () => {
  isConected = false;
  console.log('🟠 Desconectado de MongoDB');
});

process.on('SIGINT', async () => {
  await mongoose.connection.close();
  console.log('🔵 MongoDB desconectado manualmente');
  process.exit(0);
});

export { conectarAMongoDB, isConected };