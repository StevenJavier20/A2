import { empresaInfo } from '../config/empresa.config.js';
import Usuario from '../models/user.model.js';

export const getInfoEmpresa = (req, res) => {
  res.json({
    msg: 'Información oficial de AeroLogix',
    ...empresaInfo
  });
};

export const getEstadoEmpresa = async (req, res) => {
  const total = await Usuario.countDocuments();
  const clientes = await Usuario.countDocuments({ rol: 'Cliente' });
  const supervisores = await Usuario.countDocuments({ rol: 'Supervisor' });
  const admins = await Usuario.countDocuments({ rol: 'Administrador' });

  res.json({
    empresa: empresaInfo.nombre,
    totalUsuarios: total,
    detalle: { clientes, supervisores, admins },
    fechaServidor: new Date().toLocaleString()
  });
};