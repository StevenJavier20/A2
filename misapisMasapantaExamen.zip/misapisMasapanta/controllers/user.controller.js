import Usuario from '../models/user.model.js';

// ✅ Obtener todos los usuarios
export const getAllUsuarios = async (req, res) => {
  try {
    const usuarios = await Usuario.find();
    res.json(usuarios);
  } catch (error) {
    console.error('❌ Error al obtener usuarios:', error);
    res.status(500).json({ msg: 'Error al obtener usuarios' });
  }
};

// ✅ Crear usuario
export const postUsuario = async (req, res) => {
  try {
    console.log('📩 Datos recibidos:', req.body); // <-- Verifica si llega bien desde el frontend

    const nuevoUsuario = new Usuario(req.body);
    await nuevoUsuario.save();

    console.log('✅ Usuario guardado correctamente:', nuevoUsuario);
    res.json({ msg: 'Usuario creado correctamente', nuevoUsuario });
  } catch (error) {
    console.error('❌ Error al guardar usuario:', error.message);
    res.status(500).json({ msg: 'Error al guardar usuario', error: error.message });
  }
};

// ✅ Actualizar usuario
export const putUsuario = async (req, res) => {
  try {
    const { id } = req.params;
    const actualizado = await Usuario.findByIdAndUpdate(id, req.body, { new: true });
    res.json({ msg: 'Usuario actualizado correctamente', actualizado });
  } catch (error) {
    console.error('❌ Error al actualizar usuario:', error.message);
    res.status(500).json({ msg: 'Error al actualizar usuario', error: error.message });
  }
};

// ✅ Eliminar usuario
export const deleteUsuario = async (req, res) => {
  try {
    const { id } = req.params;
    await Usuario.findByIdAndDelete(id);
    res.json({ msg: 'Usuario eliminado correctamente' });
  } catch (error) {
    console.error('❌ Error al eliminar usuario:', error.message);
    res.status(500).json({ msg: 'Error al eliminar usuario', error: error.message });
  }
};