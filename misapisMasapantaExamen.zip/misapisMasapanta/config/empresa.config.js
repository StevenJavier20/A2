export const empresaInfo = {
  nombre: 'AeroLogix',
  descripcion: 'Empresa líder en monitoreo y control de drones.',
  slogan: 'Innovación que despega hacia el futuro.',
  contacto: {
    email: 'contacto@aerologix.com',
    telefono: '+593 987 654 321',
    direccion: 'Av. Tecnológica #45, Quito, Ecuador'
  },
  redes: {
    web: 'https://aerologix.com',
    instagram: 'https://instagram.com/aerologix',
    linkedin: 'https://linkedin.com/company/aerologix'
  }
};