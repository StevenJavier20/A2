const BASE_URL = 'http://localhost:3000/api';

// === ELEMENTOS DEL DOM ===
const btnCargar = document.getElementById('btnCargar');
const btnNuevo = document.getElementById('btnNuevo');
const modal = document.getElementById('formulario');
const cancelar = document.getElementById('cancelar');
const guardar = document.getElementById('guardarUsuario');
const tabla = document.querySelector('#tablaUsuarios tbody');

const btnInfoEmpresa = document.getElementById('btnInfoEmpresa');
const btnEstadoEmpresa = document.getElementById('btnEstadoEmpresa');
const panelInfo = document.getElementById('panelInfo');
const panelEstado = document.getElementById('panelEstado');

let usuarioActual = null; // Usuario en edición

// === FUNCIONES DE USUARIOS ===
btnNuevo.addEventListener('click', () => {
  usuarioActual = null;
  guardar.textContent = '💾 Guardar';
  modal.classList.remove('hidden');
});

cancelar.addEventListener('click', () => modal.classList.add('hidden'));

btnCargar.addEventListener('click', async () => {
  tabla.innerHTML = '<tr><td colspan="5">Cargando...</td></tr>';
  const res = await fetch(`${BASE_URL}/usuarios`);
  const usuarios = await res.json();
  mostrarUsuarios(usuarios);
});

function mostrarUsuarios(lista) {
  tabla.innerHTML = '';
  lista.forEach(u => {
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${u.nombre}</td>
      <td>${u.correo}</td>
      <td>${u.rol}</td>
      <td>${new Date(u.fechaRegistro).toLocaleDateString()}</td>
      <td>
        <button onclick="editarUsuario('${u._id}')">✏️</button>
        <button onclick="eliminarUsuario('${u._id}')">🗑️</button>
      </td>
    `;
    tabla.appendChild(fila);
  });
}

async function editarUsuario(id) {
  const res = await fetch(`${BASE_URL}/usuarios`);
  const usuarios = await res.json();
  const usuario = usuarios.find(u => u._id === id);

  if (!usuario) return alert('Usuario no encontrado');

  usuarioActual = usuario;
  modal.classList.remove('hidden');

  document.getElementById('nombre').value = usuario.nombre;
  document.getElementById('correo').value = usuario.correo;
  document.getElementById('password').value = '';
  document.getElementById('rol').value = usuario.rol;

  guardar.textContent = '💾 Actualizar';
}

guardar.addEventListener('click', async () => {
  const nombre = document.getElementById('nombre').value;
  const correo = document.getElementById('correo').value;
  const password = document.getElementById('password').value;
  const rol = document.getElementById('rol').value;

  if (usuarioActual) {
    await fetch(`${BASE_URL}/usuarios/${usuarioActual._id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, correo, ...(password && { password }), rol })
    });
    usuarioActual = null;
    guardar.textContent = '💾 Guardar';
  } else {
    await fetch(`${BASE_URL}/usuarios`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre, correo, password, rol })
    });
  }

  modal.classList.add('hidden');
  btnCargar.click();
  document.getElementById('nombre').value = '';
  document.getElementById('correo').value = '';
  document.getElementById('password').value = '';
  document.getElementById('rol').value = 'Cliente';
});

async function eliminarUsuario(id) {
  if (confirm('¿Eliminar este usuario?')) {
    await fetch(`${BASE_URL}/usuarios/${id}`, { method: 'DELETE' });
    btnCargar.click();
  }
}

// === FUNCIONES DE EMPRESA ===
btnInfoEmpresa?.addEventListener('click', async () => {
  panelInfo.innerHTML = 'Cargando información...';
  const res = await fetch(`${BASE_URL}/empresa`);
  const data = await res.json();
  panelInfo.innerHTML = `
    <h3>${data.nombre}</h3>
    <p>${data.descripcion}</p>
    <p><strong>Slogan:</strong> ${data.slogan}</p>
    <p><strong>Contacto:</strong> ${data.contacto.email} | ${data.contacto.telefono}</p>
    <p><strong>Dirección:</strong> ${data.contacto.direccion}</p>
    <a href="${data.redes.web}" target="_blank">🌐 Sitio Web</a>
  `;
});

btnEstadoEmpresa?.addEventListener('click', async () => {
  panelEstado.innerHTML = 'Cargando estado del sistema...';
  const res = await fetch(`${BASE_URL}/empresa/estado`);
  const data = await res.json();
  panelEstado.innerHTML = `
    <h3>Estado actual - ${data.empresa}</h3>
    <p>Total de usuarios: ${data.totalUsuarios}</p>
    <ul>
      <li>Clientes: ${data.detalle.clientes}</li>
      <li>Supervisores: ${data.detalle.supervisores}</li>
      <li>Administradores: ${data.detalle.admins}</li>
    </ul>
    <p><em>Actualizado:</em> ${data.fechaServidor}</p>
  `;
});

window.addEventListener('DOMContentLoaded', () => btnCargar.click());