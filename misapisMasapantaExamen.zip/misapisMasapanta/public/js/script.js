// === PANEL AEROLOGIX ===

// Botones principales
const btnInfo = document.getElementById('btnInfoEmpresa');
const btnEstado = document.getElementById('btnEstadoEmpresa');

// Contenedores de información
const panelInfo = document.getElementById('panelInfo');
const panelEstado = document.getElementById('panelEstado');

// === CARGAR INFORMACIÓN DE LA EMPRESA ===
btnInfo.addEventListener('click', async () => {
  panelInfo.innerHTML = "<p>Cargando información de la empresa...</p>";
  try {
    const res = await fetch('/empresa');
    if (!res.ok) throw new Error('No se pudo obtener la información.');
    const data = await res.json();

    panelInfo.innerHTML = `
      <h3 style="color:#00c3ff;">🌍 ${data.nombre}</h3>
      <p><strong>Descripción:</strong> ${data.descripcion}</p>
      <p><strong>Slogan:</strong> ${data.slogan}</p>
      <p><strong>Email:</strong> ${data.contacto.email}</p>
      <p><strong>Teléfono:</strong> ${data.contacto.telefono}</p>
      <p><strong>Dirección:</strong> ${data.contacto.direccion}</p>
    `;
  } catch (err) {
    panelInfo.innerHTML = `<p style="color:red;">⚠️ Error: ${err.message}</p>`;
  }
});

// === CARGAR ESTADO DEL SISTEMA ===
btnEstado.addEventListener('click', async () => {
  panelEstado.innerHTML = "<p>Cargando estado del sistema...</p>";
  try {
    const res = await fetch('/empresa/estado');
    if (!res.ok) throw new Error('No se pudo obtener el estado del sistema.');
    const data = await res.json();

    panelEstado.innerHTML = `
      <h3 style="color:#00aaff;">📊 Estado del Sistema</h3>
      <p><strong>Usuarios Totales:</strong> ${data.totalUsuarios}</p>
      <p><strong>Clientes:</strong> ${data.detalle.clientes}</p>
      <p><strong>Supervisores:</strong> ${data.detalle.supervisores}</p>
      <p><strong>Administradores:</strong> ${data.detalle.admins}</p>
      <p><strong>Fecha del Servidor:</strong> ${data.fechaServidor}</p>
    `;
  } catch (err) {
    panelEstado.innerHTML = `<p style="color:red;">⚠️ Error: ${err.message}</p>`;
  }
});